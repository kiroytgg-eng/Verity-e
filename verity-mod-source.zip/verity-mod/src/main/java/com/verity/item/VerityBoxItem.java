package com.verity.item;

import com.verity.VerityEntities;
import com.verity.entity.VerityBoxEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class VerityBoxItem extends Item {
    public VerityBoxItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        if (!world.isClient) {
            BlockPos pos = context.getBlockPos().offset(context.getSide());
            Vec3d at = Vec3d.ofBottomCenter(pos);
            VerityBoxEntity box = VerityEntities.BOX.create(world);
            if (box == null) return ActionResult.FAIL;
            PlayerEntity player = context.getPlayer();
            float yaw = player != null ? player.getYaw() : 0f;
            box.refreshPositionAndAngles(at.x, at.y, at.z, yaw, 0f);
            world.spawnEntity(box);
            if (player != null && !player.isCreative()) {
                context.getStack().decrement(1);
            }
        }
        return ActionResult.success(world.isClient);
    }
}
