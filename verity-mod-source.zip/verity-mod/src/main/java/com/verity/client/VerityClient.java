package com.verity.client;

import com.verity.VerityEntities;
import com.verity.VerityItems;
import com.verity.client.render.VerityBallRenderer;
import com.verity.client.render.VerityBoxRenderer;
import com.verity.entity.VerityBallEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.util.math.Box;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.Locale;

public class VerityClient implements ClientModInitializer {
    private static KeyBinding configKey;
    private static KeyBinding talkKey;
    private static long lastEventMs;

    @Override
    public void onInitializeClient() {
        VerityConfig.load();
        EntityRendererRegistry.register(VerityEntities.BOX, VerityBoxRenderer::new);
        EntityRendererRegistry.register(VerityEntities.BALL, VerityBallRenderer::new);

        VerityBallEntity.CLIENT_TALK = b -> openTalk();
        VerityBallEntity.CLIENT_GREET = VerityClient::greet;

        configKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.verity.config",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J, "key.categories.verity"));
        talkKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.verity.talk",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.verity"));

        ClientTickEvents.END_CLIENT_TICK.register(VerityClient::tick);
        ClientSendMessageEvents.ALLOW_CHAT.register(VerityClient::onChat);
    }

    // ---------------------------------------------------------------- helpers

    /** Verity te escucha si esta cerca (la bola) O si la llevas en el inventario como Verity™. */
    public static boolean hasVerity() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return false;
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            if (inv.getStack(i).isOf(VerityItems.BALL)) return true;
        }
        return findBall() != null;
    }

    public static VerityBallEntity findBall() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return null;
        VerityBallEntity best = null;
        double bestD = 48 * 48;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof VerityBallEntity b && b.getBallState() != VerityBallEntity.STATE_HELD) {
                if (b.getOwnerUuid() != null && !b.getOwnerUuid().equals(mc.player.getUuid())) continue;
                double d = b.squaredDistanceTo(mc.player);
                if (d < bestD) {
                    bestD = d;
                    best = b;
                }
            }
        }
        return best;
    }

    private static void openTalk() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.setScreen(new VerityTalkScreen());
    }

    private static void greet(VerityBallEntity ball) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (ball.getOwnerUuid() != null && !ball.getOwnerUuid().equals(mc.player.getUuid())) return;
        VerityVoice.say(VerityConfig.get().greeting);
    }

    // ------------------------------------------------------------------ tick

    private static void tick(MinecraftClient mc) {
        VerityVoice.tick();
        if (mc.player == null || mc.world == null) return;

        while (configKey.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new VerityConfigScreen(null));
        }
        while (talkKey.wasPressed()) {
            if (mc.currentScreen == null && hasVerity()) openTalk();
        }

        // Verity celosa / obsesionada reacciona cuando alguien se te acerca
        if (mc.world.getTime() % 20 != 0) return;
        VerityPersonality p = VerityConfig.get().personalityEnum();
        if (p != VerityPersonality.CELOSA && p != VerityPersonality.OBSESIONADA) return;
        if (VerityVoice.isSpeaking() || VerityBrain.isBusy()) return;
        if (System.currentTimeMillis() - lastEventMs < 45000) return;
        if (!hasVerity()) return;

        ClientPlayerEntity me = mc.player;
        Box area = me.getBoundingBox().expand(5.0);
        List<PlayerEntity> players = mc.world.getEntitiesByClass(PlayerEntity.class, area, o -> o != me && !o.isSpectator());
        String note = null;
        if (!players.isEmpty()) {
            note = "El jugador " + players.get(0).getName().getString() + " se acaba de acercar mucho a tu jugador.";
        } else {
            List<VillagerEntity> v = mc.world.getEntitiesByClass(VillagerEntity.class, area.contract(2.0), o -> true);
            if (!v.isEmpty()) note = "Un aldeano se acaba de acercar mucho a tu jugador.";
        }
        if (note == null) return;
        lastEventMs = System.currentTimeMillis();
        VerityConfig cfg = VerityConfig.get();
        boolean hasKey = "groq".equalsIgnoreCase(cfg.provider) ? !cfg.groqKey.isBlank() : !cfg.geminiKey.isBlank();
        if (hasKey) {
            VerityBrain.askEvent(note);
        } else {
            VerityVoice.say(p == VerityPersonality.CELOSA
                    ? "¿Y esa persona quién es? ¿Por qué se te acerca tanto? Hmph."
                    : "Aléjate de él. Solo me necesitas a mí, ¿verdad? Solo a mí.");
        }
    }

    // ------------------------------------------------------------------ chat

    /** Si escribes "verity ..." en el chat, ella contesta (aunque la lleves en el inventario). */
    private static boolean onChat(String message) {
        String m = message.trim();
        String low = m.toLowerCase(Locale.ROOT);
        if (!low.startsWith("verity")) return true;
        if (low.length() > 6 && Character.isLetterOrDigit(low.charAt(6))) return true;
        if (!hasVerity()) return true;
        String rest = m.substring(6).replaceFirst("^[\\s,:;!¡¿?.\\-]+", "");
        VerityBrain.ask(rest.isEmpty() ? "Hola" : rest);
        return true;
    }
}
