package com.verity.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/** Ventana para hablarle a Verity (click derecho en la bola, click derecho con el item, o tecla V). */
public class VerityTalkScreen extends Screen {
    private TextFieldWidget field;

    public VerityTalkScreen() {
        super(Text.literal("Hablar con Verity"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2, cy = this.height / 2;
        field = new TextFieldWidget(this.textRenderer, cx - 150, cy - 10, 300, 20, Text.literal("Mensaje"));
        field.setMaxLength(240);
        addDrawableChild(field);
        setInitialFocus(field);
        addDrawableChild(ButtonWidget.builder(Text.literal("Enviar"), b -> send()).dimensions(cx - 150, cy + 16, 148, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cancelar"), b -> close()).dimensions(cx + 2, cy + 16, 148, 20).build());
    }

    private void send() {
        String msg = field.getText().trim();
        if (msg.isEmpty()) return;
        MinecraftClient mc = this.client;
        mc.setScreen(null);
        String name = mc.player != null ? mc.player.getName().getString() : "Tú";
        mc.inGameHud.getChatHud().addMessage(Text.literal("<" + name + "> " + msg));
        VerityBrain.ask(msg);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257 || keyCode == 335) { // Enter
            send();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Habla con Verity™"), this.width / 2, this.height / 2 - 28, 0xFFFF55);
        super.render(ctx, mouseX, mouseY, delta);
    }
}
