"""Convierte el modelo de la caja (BBS) a quads simples + genera iconos. Uso: python3 build_assets.py <VerityPack_dir> <out_resources_dir>"""
import json, sys, os, numpy as np
from PIL import Image

pack, out = sys.argv[1], sys.argv[2]
anim = json.load(open(os.path.join(pack, 'VerityBox/box_animations.bbs.json')))
TW, TH = anim['model']['texture']

def face_quads(frm, size, uvs):
    x0, y0, z0 = frm; sx, sy, sz = size
    x1, y1, z1 = x0 + sx, y0 + sy, z0 + sz
    def uvq(r, flip_pairs):
        a, b, c, d = r
        return [(a, b), (c, b), (c, d), (a, d)]  # TL TR BR BL
    q = []
    # Corner order for each face is TL, TR, BR, BL of its uv rect.
    # BBS: front = +Z? we choose front=-Z (north) ; verified visually with the preview.
    faces = {
        'front':  ([(x1, y1, z0), (x0, y1, z0), (x0, y0, z0), (x1, y0, z0)], (0, 0, -1)),
        'back':   ([(x0, y1, z1), (x1, y1, z1), (x1, y0, z1), (x0, y0, z1)], (0, 0, 1)),
        'right':  ([(x0, y1, z0), (x0, y1, z1), (x0, y0, z1), (x0, y0, z0)], (-1, 0, 0)),
        'left':   ([(x1, y1, z1), (x1, y1, z0), (x1, y0, z0), (x1, y0, z1)], (1, 0, 0)),
        'top':    ([(x1, y1, z0), (x0, y1, z0), (x0, y1, z1), (x1, y1, z1)], (0, 1, 0)),
        'bottom': ([(x1, y0, z1), (x0, y0, z1), (x0, y0, z0), (x1, y0, z0)], (0, -1, 0)),
    }
    for name, (corners, n) in faces.items():
        r = uvs[name]
        uv = uvq(r, None)
        q.append({'n': n, 'v': [[c[0], c[1], c[2], uv[i][0] / TW, uv[i][1] / TH] for i, c in enumerate(corners)], 'face': name})
    return q

groups = {}
for gname, g in anim['model']['groups'].items():
    quads = []
    for c in g.get('cubes', []):
        quads += face_quads(c['from'], c['size'], c['uvs'])
    groups[gname] = {'parent': g.get('parent'), 'origin': g.get('origin', [0, 0, 0]), 'quads': quads}

os.makedirs(out, exist_ok=True)
json.dump({'groups': groups}, open(os.path.join(out, 'box_model.json'), 'w'))
print('box quads', {k: len(v['quads']) for k, v in groups.items()})
